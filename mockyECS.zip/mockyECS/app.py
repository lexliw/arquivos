from flask import Flask, escape, request

app = Flask(__name__)

#GET simples
@app.route('/',methods = ['GET'])
def hello():
    resp = """
    {
        "name": "%s",
        "instructions": "%s",
        "teste": "%s"
    }
    """
    resp = resp % ('José da Silva', 'superior', 'ok')
    return resp, 200, {'Content-Type': 'application/json; charset=utf-8'}

#GET 
@app.route('/v2.0/api/sintomas/ultimo-id',methods = ['GET'])
def ultimoId():

    existsAuth = request.headers.get('Authorization')
    if existsAuth:    
        resp = """
            "279"
        """ 
        http_code = 200
    else:
        resp = """
            {
                "Message": "Authorization has been denied for this request."
            }
        """
        http_code = 401

    return resp, http_code, {'Content-Type': 'application/json; charset=utf-8'}

#GET 
@app.route('/v2.0/api/chamado/arquivados/total',methods = ['GET'])
def totalArquivados():

    existsAuth = request.headers.get('Authorization')
    if existsAuth:    
        resp = """
            6
        """ 
        http_code = 200
    else:
        resp = """
            {
                "Message": "Authorization has been denied for this request."
            }
        """
        http_code = 401

    return resp, http_code, {'Content-Type': 'application/json; charset=utf-8'}

#GET com path param
@app.route('/v2.0/api/ocorrencias/<id>',methods = ['GET'])
def ocorrencia(id):

    existsAuth = request.headers.get('Authorization')
    if existsAuth:    
        f = open("ocorrenciaResponse.txt", "r")    
        resp = f.read() % (id)
        http_code = 200
    else:
        resp = """
            {
                "Message": "Authorization has been denied for this request."
            }
        """
        http_code = 401

    return resp, http_code, {'Content-Type': 'application/json; charset=utf-8'}

#GET com path param
@app.route('/v2.0/api/chamado/arquivados',methods = ['GET'])
def arquivados():

    existsAuth = request.headers.get('Authorization')
    if existsAuth:
        f = open("arquivadosResponse.json", "r")    
        resp = f.read()
        http_code = 200
    else:
        resp = """
            {
                "Message": "Authorization has been denied for this request."
            }
        """
        http_code = 401

    return resp, http_code, {'Content-Type': 'application/json; charset=utf-8'}


#GET com path param
@app.route('/v2.0/api/ocorrencias',methods = ['GET'])
def listaChamados():

    existsAuth = request.headers.get('Authorization')
    if existsAuth:    
        f = open("listaChamadosResponse.json", "r")    
        resp = f.read()
        http_code = 200
    else:
        resp = """
            {
                "Message": "Authorization has been denied for this request."
            }
        """
        http_code = 401

    return resp, http_code, {'Content-Type': 'application/json; charset=utf-8'}

#GET com query param
@app.route('/search',methods = ['GET'])
def search():
    user = request.args.get('user')
    name = request.args.get('name')
    resp = """
    {
        "id": "%s",
        "user": "%s",
        "name": "%s"
    }
    """
    resp = resp % ('112233', user, name)
    return resp, 200, {'Content-Type': 'application/json; charset=utf-8'}

#POST 
@app.route('/v2.0/api/ocorrencias/semfoto',methods = ['POST'])
def abreChamado():
    req = request.json

#     { 
#    "TipoOcorrencia":15,
#    "SubTipoOcorrencia":7,
#    "ClassificacaoOcorrencia":44,
#    "Endereco":"96e7fe56ff7278bddcdd11ce7a687acfa63ee9b4d5de35b81030135e42f1f58f8b2cfdf65809b8373af3aef62ec56c25c0807a6b728781893c2af057327aae65",
#    "Uniorg":"1523686",
#    "Descricao":"teste Alex mock 1",
#    "Telefone":"490425dbcf42c340bb3348a83ca9ffaa",
#    "CamposCustomizados":"2c2a58b88d2b41712861d1e0e6028e330b67f6b637f534afad79b23cb8c9a522",
#    "Fotos":[],
#    "Apelido":"Mock 1"
# }

    existsAuth = request.headers.get('authorization')
    if existsAuth: 
        tipoOcorrencia = req['tipoOcorrencia']
        subTipoOcorrencia = req['subTipoOcorrencia']
        classificacaoOcorrencia = req['classificacaoOcorrencia']
        endereco = req['endereco']
        uniorg = req['uniorg']
        descricao = req['descricao']
        telefone = req['telefone']
        camposCustomizados = req['camposCustomizados']
        fotos = req['fotos']
        apelido = req['apelido']    

        print('############################################################')
        print('# tipoOcorrencia: ' + str(tipoOcorrencia))
        print('# subTipoOcorrencia: ' + str(subTipoOcorrencia))
        print('# classificacaoOcorrencia: ' + str(classificacaoOcorrencia))
        print('# endereco: ' + endereco)
        print('# uniorg: ' + uniorg)
        print('# descricao: ' + descricao)
        print('# telefone: ' + telefone)
        print('# camposCustomizados: ' + camposCustomizados)
        print('# fotos: ' + fotos)
        print('# apelido: ' + apelido)
        print('############################################################')

        resp = """
            {
                "id": 41524,
                "criadoEm": "2019-12-23T11:27:49.045458-03:00",
                "status": null
            }
        """
        http_code = 200
    else:
        resp = """
            {
                "Message": "Authorization has been denied for this request."
            }
        """
        http_code = 401

    return resp, http_code, {'Content-Type': 'application/json; charset=utf-8'}

#POST 
@app.route('/v2.0/api/funcionario/apelido',methods = ['POST'])
def alteraApelido():
    req = request.json

# {
# 	"CPF": "22a3f6981b90a686414a403a63a5e826",
# 	"Apelido": "ALVARO BARROS DE SOUZA"
# }

    existsAuth = request.headers.get('Authorization')
    if existsAuth: 
        cpf = req['cpf']
        apelido = req['apelido']

        print('cpf: ' + cpf)
        print('apelido: ' + apelido)

        resp = "Apelido do funcionário alterado com sucesso"
    
        http_code = 200
    else:
        resp = """
            {
                "Message": "Authorization has been denied for this request."
            }
        """
        http_code = 401

    return resp, http_code, {'Content-Type': 'application/json; charset=utf-8'}


if __name__ == '__main__':
   app.run(host='0.0.0.0', port=8081, debug = True)